const mysql =require('mysql');
const conn = mysql.createConnection({// function hota jisme 4 parameter hote hai
    host:'localhost',
    user:'root',
    password:'',
    database:'data'

});
conn.connect((err)=>{// bydefcult err parameter hota hi hai
if (err) {//agar iske angar kunch hme bata de
   console.warn('this is not connected data ') 
} else {
    console.log(' connected data ') ; //connected data base   
}

})
module.exports = conn;