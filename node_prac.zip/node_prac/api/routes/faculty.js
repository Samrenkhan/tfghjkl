const express = require('express'); // express ko input kardiya.....
// ek router create karna hai ye router hamko express se milta hai
const router = express.Router()// 
// yaha andar me hmlog router.  http ka alag alag use karpaye...getrequest.putrequest..postrequest usedkarpaye...
router.get('/', (req, res, next) => {
    res.status(200).json({//200 status okk 
        message: "this is faculty get request"//msg return karenge jisko ye call karega
    })//jis json hm data base data denge jo isse call karega..
}) //get request ham data chahiye to get ka use karte hai


router.post('/', (req, res, next) => {
    res.status(200).json({//200 status okk 
        message: "this is faculty post request"//msg return karenge jisko ye call karega
    })//jis json hm data base data denge jo isse call karega..
}) //post request ham data chahiye to post ka use karte hai

// router usekarna app par jana uska para path dena hai





// js used kar paye
module.exports = router;