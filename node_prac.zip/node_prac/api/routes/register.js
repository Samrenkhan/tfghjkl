const express = require('express'); // express ko input kardiya.....
// Enable CORS for all routes
const cors = require('cors');
const app = express();
app.use(express.json());
//validation library
const Joi = require('joi');

const validator = require('validator');
const conn =require('./config')
// ek router create() karna hai ye router hamko express se milta hai

const router = express.Router()// 
// yaha andar me hmlog router.  http ka alag alag use karpaye...getrequest.putrequest..postrequest usedkarpaye...
router.get('/', (req, res, next) => {
    // res.status(200).json({//200 status okk 
    //     message: "this is register get request"//msg return karenge jisko ye call karega
    // })//jis json hm data base data denge jo isse call karega..
// data ko fetch karenge
conn.query("SELECT * from student_emp",(err,result)=>{
    if (err) {
        res.send("not select query")
    } else {
        // console.warn("result",result) 
        res.send(result)  ;
    }
    
    
    })// jobhi ap query laga skte hai 



}) //get request ham data chahiye to get ka use karte hai


  // Assuming you have a JSON payload in the request body with the data to be inserted.
router.post("/insert", (req, res, next) => {
  const { name, email, password } = req.body;
///validation 
const schema = Joi.object({
  name: Joi.string()
      .alphanum()
      .min(3)
      .max(30)
      .required(),
     email:Joi.string().required() ,
     password: Joi.string()
     .pattern(new RegExp('^[a-zA-Z0-9]{3,30}$'))
    })

      let result=schema.validate(req.body)
      
      if (result.error) {
        res.status(400).send(result.error.details[0].message)
        return
        
      }
    
 
  // Save the email to the database (in this case, the in-memory array)
 // yaha andar me hmlog router.  http ka alag alag use karpaye...getrequest.putrequest..postrequest usedkarpaye...

  // res.status(200).json({//200 status okk 
  //     message: "this is register get request"//msg return karenge jisko ye call karega
  // })//jis json hm data base data denge jo isse call karega..
// data ko fetch karenge


// Check if the email exists in the database
const sql= 'SELECT * FROM student_emp WHERE email = ?';

    if (err) {
      console.error("Error in email check query:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }else{
    res.status(200).json({ message: "Email is valid", isValid: true });
  } 
  console.log("Insert successful");
  res.status(200).json({ message: "Insert successful", insertId: result.insertId });



// jobhi ap query laga skte hai 



 //get request ham data chahiye to get ka use karte hai

  
  
   
 sql = `INSERT INTO student_emp (name, email, password) VALUES (?, ?, ?)`;


  // Execute the query with the provided data
  conn.query(sql, [name, email,password], (err, result) => {
    if (err) {
      console.error("Error in insert query:", err);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      console.log("Insert successful");
      res.status(200).json({ message: "Insert successful", insertId: result.insertId });
    }
  });

}
);
router.post("/update", (req, res) => {
  // const { id } = req.params;

  // Assuming you have a JSON payload in the request body with the data to be inserted.
  const { name, email, password } = req.body;
 // Example SQL query for update. Adjust this based on your table structure.
 const sql = `UPDATE student_emp SET name = ?, email= ?, password = ? `;
  // Execute the query with the provided data
  conn.query(sql, [name, email, password], (err, result) => {
    if (err) {
      console.error("Error in Update query:", err);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      console.log("Update successful");
      res.status(201).json({ message: "update successful", insertId: result.insertId });
    }
  });
});



router.delete("/delete/:id", (req, res) => {
  const itemId = req.params.id;
  const sql = 'DELETE FROM student_emp WHERE id = ?';

  conn.query(sql, [itemId], (err, result) => {
    if (err) {
      console.error("Error in delete query:", err);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      if (result.affectedRows > 0) {
        console.log("Delete successful");
        res.status(200).json({ message: "Delete successful" });
      } else {
        console.log("Item not found");
        res.status(404).json({ error: "Item not found" });
      }
    }
  });
});

// router.post('/', (req, res, next) => {
//     res.status(200).json({//200 status okk 
//         message: "this is register post request"//msg return karenge jisko ye call karega
//     })//jis json hm data base data denge jo isse call karega..
// }) //post request ham data chahiye to post ka use karte hai

// router usekarna app par jana uska para path dena hai




// js used kar paye
module.exports = router;