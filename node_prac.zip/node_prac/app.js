const express = require('express')
const app = express()
const bodyParser= require('body-parser')
app.use(bodyParser.urlencoded({
  extended:true
}))
app.use(bodyParser.json())
//router ka path
// const validateRoute = require('./api/routes/validator');
const registerRoute =require('./api/routes/register');
const facultyRoute = require('./api/routes/faculty');
//data base create
// const conn = require('./api/routes/config');

//endpointjobhi rakhna chahte hai
app.use('/register',registerRoute)// jabhi koi /register hit karega wo jayega registerrouterme
app.use('/faculty',facultyRoute)// jabhi koi /faculty hit karega wo jayega facultyRoute me
// middleware only three type req,res,next

// app.use((req,res,next)=>{
  // agar isse koi call karega liya kiya return karega 200 status means ok
//   res.status(200).json({
//     message:'app is running'
//   })
// })



app.use((req,res,next)=>{
 // agar isse koi call karega liya kiya return karega 200 status means ok
  res.status(404).json({
    message:'URL NOT BAD REQUEST'
  })//koi /staff url nhi hota uska msg print kra denge
})




// app.get('/', (req, res) => {
//   res.send('Hello World!')
// })



// dusri jagah exports karna hai
module.exports = app;