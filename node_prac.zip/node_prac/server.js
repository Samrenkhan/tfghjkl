// http ki library tha wo add kardiya.....

const http =require('http')

// app .js file create karna port krna server .js se

const app= require('./app')
// ek server create ho jayega
const server = http.createServer(app);// app is server me post ho gya

// port karne ke liye server run ho raha 
 server.listen(90,console.log('app is runing'));



// const express = require('express')
// const app = express()
// const port = 3000

// app.get('/', (req, res) => {
//   res.send('Hello World!')
// })

// app.listen(port, () => {
//   console.log(`Example app listening on port ${port}`)
// })